package com.aioptimizer.helper

import android.content.ComponentName
import android.content.ServiceConnection
import android.os.IBinder
import android.util.Log
import com.aioptimizer.IShizukuService
import com.aioptimizer.service.ShizukuUserService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import rikka.shizuku.Shizuku

/**
 * Управляет жизненным циклом соединения с Shizuku.
 * Предоставляет готовый IShizukuService для выполнения команд.
 */
object ShizukuHelper {

    private const val TAG = "ShizukuHelper"
    private const val SHIZUKU_PERMISSION_REQUEST_CODE = 42

    sealed class ShizukuState {
        object NotInstalled : ShizukuState()
        object NotRunning : ShizukuState()
        object NoPermission : ShizukuState()
        object Connecting : ShizukuState()
        object Connected : ShizukuState()
        data class Error(val message: String) : ShizukuState()
    }

    private val _state = MutableStateFlow<ShizukuState>(ShizukuState.NotInstalled)
    val state: StateFlow<ShizukuState> = _state

    private var _service: IShizukuService? = null
    val service: IShizukuService? get() = _service

    private val userServiceArgs = Shizuku.UserServiceArgs(
        ComponentName("com.aioptimizer", ShizukuUserService::class.java.name)
    )
        .daemon(false)
        .processNameSuffix("optimizer_service")
        .debuggable(false)
        .version(ShizukuUserService.VERSION)

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            if (binder != null && binder.pingBinder()) {
                _service = IShizukuService.Stub.asInterface(binder)
                _state.value = ShizukuState.Connected
                Log.d(TAG, "Shizuku service connected, version=${_service?.version}")
            } else {
                _state.value = ShizukuState.Error("Binder недоступен")
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            _service = null
            _state.value = ShizukuState.NotRunning
            Log.w(TAG, "Shizuku service disconnected")
        }
    }

    // ─── Слушатели Shizuku ────────────────────────────────────────────────────

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        Log.d(TAG, "Shizuku binder received")
        checkAndConnect()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        Log.w(TAG, "Shizuku binder dead")
        _service = null
        _state.value = ShizukuState.NotRunning
    }

    private val requestPermissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == SHIZUKU_PERMISSION_REQUEST_CODE) {
                if (grantResult == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    bindService()
                } else {
                    _state.value = ShizukuState.NoPermission
                }
            }
        }

    // ─── Публичные методы ─────────────────────────────────────────────────────

    fun init() {
        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
        Shizuku.addRequestPermissionResultListener(requestPermissionResultListener)
    }

    fun destroy() {
        Shizuku.removeBinderReceivedListener(binderReceivedListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
        Shizuku.removeRequestPermissionResultListener(requestPermissionResultListener)
        unbindService()
    }

    fun requestPermission() {
        Shizuku.requestPermission(SHIZUKU_PERMISSION_REQUEST_CODE)
    }

    fun checkAndConnect() {
        when {
            !Shizuku.pingBinder() -> {
                _state.value = ShizukuState.NotRunning
            }
            !hasPermission() -> {
                _state.value = ShizukuState.NoPermission
            }
            else -> bindService()
        }
    }

    fun hasPermission(): Boolean = try {
        Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED
    } catch (e: IllegalStateException) {
        false
    }

    fun isConnected(): Boolean = _state.value is ShizukuState.Connected && _service != null

    // ─── Приватные методы ─────────────────────────────────────────────────────

    private fun bindService() {
        try {
            _state.value = ShizukuState.Connecting
            Shizuku.bindUserService(userServiceArgs, serviceConnection)
        } catch (e: Exception) {
            Log.e(TAG, "bindUserService failed", e)
            _state.value = ShizukuState.Error(e.message ?: "Ошибка подключения")
        }
    }

    private fun unbindService() {
        try {
            if (isConnected()) {
                Shizuku.unbindUserService(userServiceArgs, serviceConnection, true)
            }
        } catch (e: Exception) {
            Log.e(TAG, "unbindService failed", e)
        }
        _service = null
    }
}
