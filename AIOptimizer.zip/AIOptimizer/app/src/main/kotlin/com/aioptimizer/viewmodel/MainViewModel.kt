package com.aioptimizer.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aioptimizer.helper.ShizukuHelper
import com.aioptimizer.optimizer.AIOptimizer
import com.aioptimizer.optimizer.OptimizationMode
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {

    val optimizer = AIOptimizer(app)

    // ─── Состояние UI ─────────────────────────────────────────────────────────

    data class UiState(
        val shizukuState: ShizukuHelper.ShizukuState = ShizukuHelper.ShizukuState.NotInstalled,
        val lastResult: String? = null,
        val lastResultSuccess: Boolean = true,
        val showResultSnackbar: Boolean = false
    )

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState

    // Проброс состояний из оптимизатора
    val currentMode = optimizer.currentMode
    val deviceStats = optimizer.stats
    val isOptimizing = optimizer.isOptimizing
    val shizukuState = ShizukuHelper.state

    // ─── Инициализация ────────────────────────────────────────────────────────

    init {
        ShizukuHelper.init()

        // Следим за состоянием Shizuku
        viewModelScope.launch {
            ShizukuHelper.state.collect { state ->
                _uiState.update { it.copy(shizukuState = state) }
            }
        }

        // Периодическое обновление статистики (каждые 5 секунд)
        viewModelScope.launch {
            while (true) {
                optimizer.refreshStats()
                delay(5000)
            }
        }

        // Пробуем подключиться к Shizuku
        ShizukuHelper.checkAndConnect()
    }

    // ─── Действия пользователя ────────────────────────────────────────────────

    fun requestShizukuPermission() {
        ShizukuHelper.requestPermission()
    }

    fun applyMode(mode: OptimizationMode) {
        viewModelScope.launch {
            val result = optimizer.applyMode(mode)
            _uiState.update {
                it.copy(
                    lastResult = result.message,
                    lastResultSuccess = result.success,
                    showResultSnackbar = true
                )
            }
            delay(3000)
            _uiState.update { it.copy(showResultSnackbar = false) }
        }
    }

    fun applyAiRecommendation() {
        viewModelScope.launch {
            val stats = deviceStats.value
            val recommended = optimizer.recommendMode(stats)
            applyMode(recommended)
        }
    }

    fun dismissSnackbar() {
        _uiState.update { it.copy(showResultSnackbar = false) }
    }

    override fun onCleared() {
        super.onCleared()
        ShizukuHelper.destroy()
    }
}
