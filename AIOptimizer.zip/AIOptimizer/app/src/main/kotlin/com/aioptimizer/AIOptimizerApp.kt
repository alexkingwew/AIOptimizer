package com.aioptimizer

import android.app.Application
import com.aioptimizer.helper.ShizukuHelper

class AIOptimizerApp : Application() {

    override fun onCreate() {
        super.onCreate()
        // ShizukuHelper инициализируется в ViewModel,
        // но регистрируем провайдер на уровне Application
    }
}
