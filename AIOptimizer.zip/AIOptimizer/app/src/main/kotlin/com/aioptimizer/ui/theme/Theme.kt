package com.aioptimizer.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// ─── Цветовая схема ───────────────────────────────────────────────────────────

object AppColors {
    val Background = Color(0xFF0A0A0F)
    val Surface = Color(0xFF12121A)
    val SurfaceVariant = Color(0xFF1A1A26)
    val CardBg = Color(0xFF16161F)
    val Border = Color(0xFF252535)

    val Primary = Color(0xFF7C3AED)
    val PrimaryContainer = Color(0xFF2D1B69)
    val Secondary = Color(0xFF06B6D4)
    val SecondaryContainer = Color(0xFF083344)

    val OnBackground = Color(0xFFF1F0FF)
    val OnSurface = Color(0xFFDDDBFF)
    val OnSurfaceVariant = Color(0xFF9990CC)

    val Success = Color(0xFF22C55E)
    val Error = Color(0xFFEF4444)
    val Warning = Color(0xFFF59E0B)

    // Режимы
    val GamingGradientStart = Color(0xFF7C3AED)
    val GamingGradientEnd = Color(0xFFEC4899)
    val PerformanceGradientStart = Color(0xFFEA580C)
    val PerformanceGradientEnd = Color(0xFFFBBF24)
    val BatteryGradientStart = Color(0xFF16A34A)
    val BatteryGradientEnd = Color(0xFF84CC16)
    val SleepGradientStart = Color(0xFF1D4ED8)
    val SleepGradientEnd = Color(0xFF7C3AED)
}

private val DarkColorScheme = darkColorScheme(
    primary = AppColors.Primary,
    primaryContainer = AppColors.PrimaryContainer,
    secondary = AppColors.Secondary,
    secondaryContainer = AppColors.SecondaryContainer,
    background = AppColors.Background,
    surface = AppColors.Surface,
    surfaceVariant = AppColors.SurfaceVariant,
    onBackground = AppColors.OnBackground,
    onSurface = AppColors.OnSurface,
    onSurfaceVariant = AppColors.OnSurfaceVariant,
    error = AppColors.Error,
    outline = AppColors.Border
)

@Composable
fun AIOptimizerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = AppTypography,
        content = content
    )
}
