package com.aioptimizer.optimizer

import androidx.compose.ui.graphics.Color

/**
 * Режимы оптимизации устройства.
 * Каждый режим содержит все необходимые параметры для настройки системы.
 */
sealed class OptimizationMode(
    val id: String,
    val displayName: String,
    val description: String,
    val emoji: String,
    val primaryColor: Color,
    val secondaryColor: Color,
    val params: OptimizationParams
) {
    /** 🎮 Игровой режим — максимальная производительность для игр */
    object Gaming : OptimizationMode(
        id = "gaming",
        displayName = "Игровой",
        description = "Максимальный FPS, минимальные задержки",
        emoji = "🎮",
        primaryColor = Color(0xFF7C3AED),
        secondaryColor = Color(0xFFA855F7),
        params = OptimizationParams(
            cpuGovernor = "performance",
            gpuGovernor = "performance",
            animationScale = 0.5f,
            screenBrightness = 255,
            adaptiveBrightness = false,
            wifiEnabled = true,
            mobileDataEnabled = true,
            killBackgroundApps = true,
            dozeEnabled = false,
            dropCaches = true,
            wifiScanAlways = false,
            // Быстрый DNS для минимального пинга
            dnsOverride = Pair("1.1.1.1", "8.8.8.8")
        )
    )

    /** ⚡ Режим производительности — баланс скорости без перегрева */
    object Performance : OptimizationMode(
        id = "performance",
        displayName = "Производительность",
        description = "Высокая скорость, комфортная работа",
        emoji = "⚡",
        primaryColor = Color(0xFFEA580C),
        secondaryColor = Color(0xFFF97316),
        params = OptimizationParams(
            cpuGovernor = "schedutil",
            gpuGovernor = "simple_ondemand",
            animationScale = 0.8f,
            screenBrightness = -1, // авто
            adaptiveBrightness = true,
            wifiEnabled = true,
            mobileDataEnabled = true,
            killBackgroundApps = true,
            dozeEnabled = false,
            dropCaches = true,
            wifiScanAlways = true,
            dnsOverride = Pair("1.1.1.1", "8.8.8.8")
        )
    )

    /** 🔋 Экономия батареи — максимальное время работы */
    object BatterySaver : OptimizationMode(
        id = "battery",
        displayName = "Экономия батареи",
        description = "Продлевает заряд до максимума",
        emoji = "🔋",
        primaryColor = Color(0xFF16A34A),
        secondaryColor = Color(0xFF22C55E),
        params = OptimizationParams(
            cpuGovernor = "powersave",
            gpuGovernor = "powersave",
            animationScale = 0.5f,
            screenBrightness = 80,
            adaptiveBrightness = false,
            wifiEnabled = true,
            mobileDataEnabled = false,
            killBackgroundApps = true,
            dozeEnabled = true,
            dropCaches = true,
            wifiScanAlways = false,
            dnsOverride = null
        )
    )

    /** 🌙 Ночной / режим сна — тишина и экономия на ночь */
    object SleepMode : OptimizationMode(
        id = "sleep",
        displayName = "Ночной режим",
        description = "Минимальное потребление, покой",
        emoji = "🌙",
        primaryColor = Color(0xFF1D4ED8),
        secondaryColor = Color(0xFF3B82F6),
        params = OptimizationParams(
            cpuGovernor = "powersave",
            gpuGovernor = "powersave",
            animationScale = 0.0f, // анимации выключены
            screenBrightness = 30,
            adaptiveBrightness = false,
            wifiEnabled = false,
            mobileDataEnabled = false,
            killBackgroundApps = true,
            dozeEnabled = true,
            dropCaches = true,
            wifiScanAlways = false,
            dnsOverride = null
        )
    )

    companion object {
        fun all(): List<OptimizationMode> = listOf(Gaming, Performance, BatterySaver, SleepMode)

        fun fromId(id: String): OptimizationMode? = all().find { it.id == id }
    }
}

/**
 * Параметры оптимизации, применяемые через Shizuku.
 */
data class OptimizationParams(
    val cpuGovernor: String,
    val gpuGovernor: String,
    val animationScale: Float,
    val screenBrightness: Int,       // -1 = не менять
    val adaptiveBrightness: Boolean,
    val wifiEnabled: Boolean,
    val mobileDataEnabled: Boolean,
    val killBackgroundApps: Boolean,
    val dozeEnabled: Boolean,
    val dropCaches: Boolean,
    val wifiScanAlways: Boolean,
    val dnsOverride: Pair<String, String>? // null = не менять DNS
)
