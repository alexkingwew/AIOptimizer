package com.aioptimizer.service

import android.content.Context
import android.os.IBinder
import android.util.Log
import com.aioptimizer.IShizukuService

/**
 * Этот сервис запускается в контексте Shizuku (shell/ADB права)
 * и выполняет привилегированные операции от имени shell.
 */
class ShizukuUserService : IShizukuService.Stub() {

    companion object {
        private const val TAG = "ShizukuUserService"
        const val VERSION = 1

        // Пути к CPU sysfs
        private const val CPU_BASE = "/sys/devices/system/cpu"
        private const val GPU_GOVERNOR_MALI = "/sys/bus/platform/drivers/mali/mali0/power_policy"
        private const val GPU_GOVERNOR_ADRENO = "/sys/class/kgsl/kgsl-3d0/devfreq/governor"
    }

    // ─── CPU ──────────────────────────────────────────────────────────────────

    override fun setCpuGovernor(governor: String) {
        try {
            val cpuCount = Runtime.getRuntime().exec("nproc").inputStream
                .bufferedReader().readLine()?.trim()?.toIntOrNull() ?: 8
            for (i in 0 until cpuCount) {
                exec("echo $governor > $CPU_BASE/cpu$i/cpufreq/scaling_governor")
            }
            Log.d(TAG, "CPU governor set to: $governor")
        } catch (e: Exception) {
            Log.e(TAG, "setCpuGovernor failed", e)
        }
    }

    override fun setCpuMaxFreq(cpuIndex: Int, freqKhz: Long) {
        exec("echo $freqKhz > $CPU_BASE/cpu$cpuIndex/cpufreq/scaling_max_freq")
    }

    override fun getCpuGovernor(): String {
        return try {
            Runtime.getRuntime().exec("cat $CPU_BASE/cpu0/cpufreq/scaling_governor")
                .inputStream.bufferedReader().readLine()?.trim() ?: "unknown"
        } catch (e: Exception) {
            "unknown"
        }
    }

    // ─── GPU ──────────────────────────────────────────────────────────────────

    override fun setGpuGovernor(governor: String) {
        // Пробуем Mali (Exynos/MediaTek)
        if (exec("echo $governor > $GPU_GOVERNOR_MALI") != 0) {
            // Пробуем Adreno (Snapdragon)
            exec("echo $governor > $GPU_GOVERNOR_ADRENO")
        }
    }

    // ─── Процессы ─────────────────────────────────────────────────────────────

    override fun killBackgroundApps(packageNames: List<String>) {
        packageNames.forEach { pkg ->
            exec("am force-stop $pkg")
            Log.d(TAG, "Killed: $pkg")
        }
        // Очищаем кэши после убийства
        exec("am kill-all")
    }

    override fun getRunningPackages(): List<String> {
        return try {
            val output = Runtime.getRuntime()
                .exec("am stack list")
                .inputStream.bufferedReader().readText()
            // Парсим вывод am stack list
            output.lines()
                .filter { it.contains("packageName=") }
                .mapNotNull { line ->
                    Regex("packageName=([\\w.]+)").find(line)?.groupValues?.getOrNull(1)
                }
                .distinct()
        } catch (e: Exception) {
            emptyList()
        }
    }

    // ─── Сеть ─────────────────────────────────────────────────────────────────

    override fun setWifiEnabled(enabled: Boolean) {
        exec("svc wifi ${if (enabled) "enable" else "disable"}")
    }

    override fun setMobileDataEnabled(enabled: Boolean) {
        exec("svc data ${if (enabled) "enable" else "disable"}")
    }

    override fun setWifiScanAlwaysAvailable(enabled: Boolean) {
        val value = if (enabled) "1" else "0"
        exec("settings put global wifi_scan_always_enabled $value")
    }

    override fun setDnsServer(primary: String, secondary: String) {
        exec("ndc resolver setnetdns 1 \"\" $primary $secondary")
        exec("setprop net.dns1 $primary")
        exec("setprop net.dns2 $secondary")
    }

    // ─── Дисплей и анимации ───────────────────────────────────────────────────

    override fun setBrightness(brightness: Int) {
        val clamped = brightness.coerceIn(0, 255)
        exec("settings put system screen_brightness $clamped")
    }

    override fun setAdaptiveBrightnessEnabled(enabled: Boolean) {
        val value = if (enabled) "1" else "0"
        exec("settings put system screen_brightness_mode $value")
    }

    override fun setAnimationScale(scale: Float) {
        setWindowAnimationScale(scale)
        setTransitionAnimationScale(scale)
        setAnimatorDurationScale(scale)
    }

    override fun setWindowAnimationScale(scale: Float) {
        exec("settings put global window_animation_scale $scale")
    }

    override fun setTransitionAnimationScale(scale: Float) {
        exec("settings put global transition_animation_scale $scale")
    }

    override fun setAnimatorDurationScale(scale: Float) {
        exec("settings put global animator_duration_scale $scale")
    }

    // ─── Системные оптимизации ────────────────────────────────────────────────

    override fun setDozeEnabled(enabled: Boolean) {
        if (enabled) {
            exec("dumpsys deviceidle enable")
            exec("dumpsys deviceidle force-idle")
        } else {
            exec("dumpsys deviceidle disable")
        }
    }

    override fun dropCaches() {
        // Очистка page cache, dentries и inodes
        exec("echo 3 > /proc/sys/vm/drop_caches")
    }

    // ─── Служебные ────────────────────────────────────────────────────────────

    override fun destroy() {
        Log.d(TAG, "ShizukuUserService destroyed")
    }

    override fun getVersion(): Int = VERSION

    // ─── Вспомогательный метод ────────────────────────────────────────────────

    private fun exec(command: String): Int {
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("sh", "-c", command))
            val exitCode = process.waitFor()
            if (exitCode != 0) {
                val error = process.errorStream.bufferedReader().readText()
                Log.w(TAG, "Command '$command' exited with $exitCode: $error")
            }
            exitCode
        } catch (e: Exception) {
            Log.e(TAG, "exec failed: $command", e)
            -1
        }
    }
}
