package com.aioptimizer.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aioptimizer.helper.ShizukuHelper
import com.aioptimizer.optimizer.AIOptimizer
import com.aioptimizer.optimizer.OptimizationMode
import com.aioptimizer.ui.theme.AppColors
import com.aioptimizer.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(viewModel: MainViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    val currentMode by viewModel.currentMode.collectAsState()
    val stats by viewModel.deviceStats.collectAsState()
    val isOptimizing by viewModel.isOptimizing.collectAsState()
    val shizukuState by viewModel.shizukuState.collectAsState()

    Box(modifier = Modifier.fillMaxSize().background(AppColors.Background)) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // ─── Header ───────────────────────────────────────────────────────
            item {
                HeaderSection(currentMode = currentMode)
            }

            // ─── Shizuku статус ───────────────────────────────────────────────
            item {
                ShizukuStatusCard(
                    state = shizukuState,
                    onRequestPermission = { viewModel.requestShizukuPermission() }
                )
            }

            // ─── Статистика устройства ────────────────────────────────────────
            item {
                DeviceStatsCard(stats = stats)
            }

            // ─── AI кнопка рекомендации ───────────────────────────────────────
            item {
                AiRecommendButton(
                    isOptimizing = isOptimizing,
                    isConnected = shizukuState is ShizukuHelper.ShizukuState.Connected,
                    onClick = { viewModel.applyAiRecommendation() }
                )
            }

            // ─── Карточки режимов ─────────────────────────────────────────────
            item {
                Text(
                    "Выберите режим",
                    style = MaterialTheme.typography.titleMedium,
                    color = AppColors.OnSurfaceVariant,
                    modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)
                )
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OptimizationMode.all().forEach { mode ->
                        ModeCard(
                            mode = mode,
                            isActive = currentMode?.id == mode.id,
                            isOptimizing = isOptimizing,
                            isEnabled = shizukuState is ShizukuHelper.ShizukuState.Connected,
                            onClick = { viewModel.applyMode(mode) }
                        )
                    }
                }
            }

            item { Spacer(Modifier.height(80.dp)) }
        }

        // Snackbar результата
        AnimatedVisibility(
            visible = uiState.showResultSnackbar,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp)
        ) {
            ResultSnackbar(
                message = uiState.lastResult ?: "",
                isSuccess = uiState.lastResultSuccess,
                onDismiss = { viewModel.dismissSnackbar() }
            )
        }
    }
}

// ─── Header ───────────────────────────────────────────────────────────────────

@Composable
private fun HeaderSection(currentMode: OptimizationMode?) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                "AI Optimizer",
                style = MaterialTheme.typography.headlineLarge,
                color = AppColors.OnBackground,
                fontWeight = FontWeight.Bold
            )
            Text(
                if (currentMode != null) "Режим: ${currentMode.emoji} ${currentMode.displayName}"
                else "Режим не выбран",
                style = MaterialTheme.typography.bodyMedium,
                color = AppColors.OnSurfaceVariant
            )
        }

        // Анимированный индикатор активного режима
        if (currentMode != null) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                currentMode.primaryColor.copy(alpha = 0.4f),
                                currentMode.primaryColor.copy(alpha = 0.1f)
                            )
                        )
                    )
                    .border(1.dp, currentMode.primaryColor.copy(alpha = 0.5f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(currentMode.emoji, fontSize = 24.sp)
            }
        }
    }
}

// ─── Shizuku статус ───────────────────────────────────────────────────────────

@Composable
private fun ShizukuStatusCard(
    state: ShizukuHelper.ShizukuState,
    onRequestPermission: () -> Unit
) {
    val (icon, title, subtitle, color, showButton) = when (state) {
        is ShizukuHelper.ShizukuState.Connected ->
            StatusInfo(Icons.Filled.CheckCircle, "Shizuku подключён", "Привилегированный доступ активен", AppColors.Success, false)
        is ShizukuHelper.ShizukuState.Connecting ->
            StatusInfo(Icons.Filled.Sync, "Подключение...", "Инициализация сервиса", AppColors.Warning, false)
        is ShizukuHelper.ShizukuState.NoPermission ->
            StatusInfo(Icons.Filled.Lock, "Нет разрешения", "Нажмите для запроса доступа", AppColors.Warning, true)
        is ShizukuHelper.ShizukuState.NotRunning ->
            StatusInfo(Icons.Filled.Warning, "Shizuku не запущен", "Откройте приложение Shizuku", AppColors.Error, false)
        is ShizukuHelper.ShizukuState.NotInstalled ->
            StatusInfo(Icons.Filled.GetApp, "Shizuku не установлен", "Установите из Play Store", AppColors.Error, false)
        is ShizukuHelper.ShizukuState.Error ->
            StatusInfo(Icons.Filled.ErrorOutline, "Ошибка", state.message, AppColors.Error, false)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = AppColors.CardBg),
        border = BorderStroke(1.dp, color.copy(alpha = 0.3f)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(icon, null, tint = color, modifier = Modifier.size(22.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, color = AppColors.OnBackground)
                Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = AppColors.OnSurfaceVariant)
            }
            if (showButton) {
                FilledTonalButton(
                    onClick = onRequestPermission,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text("Разрешить", fontSize = 12.sp)
                }
            }
        }
    }
}

private data class StatusInfo(
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val title: String,
    val subtitle: String,
    val color: Color,
    val showButton: Boolean
)

// ─── Статистика устройства ────────────────────────────────────────────────────

@Composable
private fun DeviceStatsCard(stats: AIOptimizer.DeviceStats) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = AppColors.CardBg),
        border = BorderStroke(1.dp, AppColors.Border),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                "Состояние устройства",
                style = MaterialTheme.typography.titleMedium,
                color = AppColors.OnBackground
            )
            Spacer(Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatItem(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Outlined.BatteryFull,
                    label = "Батарея",
                    value = "${stats.batteryLevel}%",
                    color = when {
                        stats.batteryCharging -> AppColors.Success
                        stats.batteryLevel <= 20 -> AppColors.Error
                        stats.batteryLevel <= 40 -> AppColors.Warning
                        else -> AppColors.Success
                    },
                    subtitle = if (stats.batteryCharging) "Заряжается" else "Разряжается"
                )
                StatItem(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Outlined.Memory,
                    label = "RAM",
                    value = "${stats.ramUsedMb}MB",
                    color = when {
                        stats.ramUsagePercent >= 85 -> AppColors.Error
                        stats.ramUsagePercent >= 70 -> AppColors.Warning
                        else -> AppColors.Secondary
                    },
                    subtitle = "${stats.ramUsagePercent.toInt()}% из ${stats.ramTotalMb}MB"
                )
            }
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatItem(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Outlined.Speed,
                    label = "CPU",
                    value = stats.cpuGovernor,
                    color = AppColors.Primary,
                    subtitle = if (stats.cpuTemp > 0) "${stats.cpuTemp.toInt()}°C" else "Темп. н/д"
                )
                StatItem(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Outlined.Wifi,
                    label = "Сеть",
                    value = stats.networkType,
                    color = AppColors.Secondary,
                    subtitle = "${stats.runningAppsCount} процессов"
                )
            }
        }
    }
}

@Composable
private fun StatItem(
    modifier: Modifier = Modifier,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    color: Color,
    subtitle: String
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = AppColors.SurfaceVariant),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(icon, null, tint = color, modifier = Modifier.size(16.dp))
                Text(label, style = MaterialTheme.typography.labelSmall, color = AppColors.OnSurfaceVariant)
            }
            Spacer(Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.titleMedium, color = AppColors.OnBackground, maxLines = 1)
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = AppColors.OnSurfaceVariant, maxLines = 1)
        }
    }
}

// ─── AI кнопка ────────────────────────────────────────────────────────────────

@Composable
private fun AiRecommendButton(
    isOptimizing: Boolean,
    isConnected: Boolean,
    onClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition()
    val shimmerAlpha by infiniteTransition.animateFloat(
        initialValue = 0.6f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1000), RepeatMode.Reverse)
    )

    Button(
        onClick = onClick,
        enabled = isConnected && !isOptimizing,
        modifier = Modifier.fillMaxWidth().height(56.dp),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
        contentPadding = PaddingValues(0.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            AppColors.Primary.copy(alpha = if (isConnected) shimmerAlpha else 0.3f),
                            AppColors.Secondary.copy(alpha = if (isConnected) shimmerAlpha else 0.3f)
                        )
                    ),
                    RoundedCornerShape(16.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            if (isOptimizing) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        color = Color.White,
                        strokeWidth = 2.dp
                    )
                    Text("Оптимизация...", color = Color.White, fontWeight = FontWeight.SemiBold)
                }
            } else {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.AutoAwesome, null, tint = Color.White, modifier = Modifier.size(20.dp))
                    Text(
                        "AI: Авто-оптимизация",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
            }
        }
    }
}

// ─── Карточка режима ──────────────────────────────────────────────────────────

@Composable
private fun ModeCard(
    mode: OptimizationMode,
    isActive: Boolean,
    isOptimizing: Boolean,
    isEnabled: Boolean,
    onClick: () -> Unit
) {
    val borderColor by animateColorAsState(
        targetValue = if (isActive) mode.primaryColor else AppColors.Border,
        animationSpec = tween(300)
    )
    val bgAlpha by animateFloatAsState(
        targetValue = if (isActive) 0.12f else 0f,
        animationSpec = tween(300)
    )

    Card(
        modifier = Modifier.fillMaxWidth()
            .clickable(enabled = isEnabled && !isOptimizing, onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = if (isActive)
                mode.primaryColor.copy(alpha = bgAlpha)
            else AppColors.CardBg
        ),
        border = BorderStroke(if (isActive) 1.5.dp else 1.dp, borderColor),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Иконка режима
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(mode.primaryColor, mode.secondaryColor),
                            start = Offset(0f, 0f),
                            end = Offset(48f, 48f)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(mode.emoji, fontSize = 22.sp)
            }

            // Текст
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    mode.displayName,
                    style = MaterialTheme.typography.titleMedium,
                    color = if (isActive) mode.primaryColor else AppColors.OnBackground
                )
                Text(
                    mode.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = AppColors.OnSurfaceVariant
                )
                // Параметры
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ModeTag("CPU: ${mode.params.cpuGovernor}", mode.primaryColor)
                    ModeTag("Анм: ${mode.params.animationScale}x", mode.primaryColor)
                }
            }

            // Индикатор активности
            if (isActive) {
                Icon(
                    Icons.Filled.RadioButtonChecked,
                    null,
                    tint = mode.primaryColor,
                    modifier = Modifier.size(20.dp)
                )
            } else {
                Icon(
                    Icons.Outlined.RadioButtonUnchecked,
                    null,
                    tint = AppColors.OnSurfaceVariant,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
private fun ModeTag(text: String, color: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(color.copy(alpha = 0.15f))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text,
            style = MaterialTheme.typography.labelSmall,
            color = color
        )
    }
}

// ─── Result Snackbar ──────────────────────────────────────────────────────────

@Composable
private fun ResultSnackbar(message: String, isSuccess: Boolean, onDismiss: () -> Unit) {
    val color = if (isSuccess) AppColors.Success else AppColors.Error
    Card(
        colors = CardDefaults.cardColors(containerColor = AppColors.Surface),
        border = BorderStroke(1.dp, color.copy(alpha = 0.5f)),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                if (isSuccess) Icons.Filled.CheckCircle else Icons.Filled.Error,
                null,
                tint = color,
                modifier = Modifier.size(20.dp)
            )
            Text(
                message,
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.bodyMedium,
                color = AppColors.OnBackground
            )
            IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                Icon(Icons.Filled.Close, null, tint = AppColors.OnSurfaceVariant, modifier = Modifier.size(16.dp))
            }
        }
    }
}
