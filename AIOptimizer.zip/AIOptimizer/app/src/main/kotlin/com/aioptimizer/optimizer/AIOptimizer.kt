package com.aioptimizer.optimizer

import android.app.ActivityManager
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.util.Log
import com.aioptimizer.helper.ShizukuHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import java.io.File

/**
 * AI-оптимизатор устройства.
 * Анализирует состояние девайса и применяет оптимальные настройки через Shizuku.
 */
class AIOptimizer(private val context: Context) {

    companion object {
        private const val TAG = "AIOptimizer"
    }

    data class DeviceStats(
        val batteryLevel: Int = 0,
        val batteryCharging: Boolean = false,
        val ramUsedMb: Long = 0,
        val ramTotalMb: Long = 0,
        val ramUsagePercent: Float = 0f,
        val cpuGovernor: String = "unknown",
        val cpuTemp: Float = 0f,
        val networkType: String = "unknown",
        val runningAppsCount: Int = 0
    )

    data class OptimizationResult(
        val success: Boolean,
        val appliedSteps: List<String>,
        val failedSteps: List<String>,
        val message: String
    )

    private val _currentMode = MutableStateFlow<OptimizationMode?>(null)
    val currentMode: StateFlow<OptimizationMode?> = _currentMode

    private val _stats = MutableStateFlow(DeviceStats())
    val stats: StateFlow<DeviceStats> = _stats

    private val _isOptimizing = MutableStateFlow(false)
    val isOptimizing: StateFlow<Boolean> = _isOptimizing

    // ─── Анализ устройства ────────────────────────────────────────────────────

    suspend fun refreshStats() = withContext(Dispatchers.IO) {
        try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val memInfo = ActivityManager.MemoryInfo()
            am.getMemoryInfo(memInfo)

            val ramTotal = memInfo.totalMem / (1024 * 1024)
            val ramAvail = memInfo.availMem / (1024 * 1024)
            val ramUsed = ramTotal - ramAvail

            val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val batteryLevel = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            val isCharging = bm.isCharging

            val cpuGovernor = readFile("/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor")
                ?: "unknown"
            val cpuTemp = readCpuTemp()
            val networkType = getNetworkType()

            // AI определяет кол-во работающих приложений через ps
            val runningApps = try {
                Runtime.getRuntime().exec("ps -A").inputStream
                    .bufferedReader().readLines().size
            } catch (e: Exception) { 0 }

            _stats.value = DeviceStats(
                batteryLevel = batteryLevel,
                batteryCharging = isCharging,
                ramUsedMb = ramUsed,
                ramTotalMb = ramTotal,
                ramUsagePercent = ramUsed.toFloat() / ramTotal * 100f,
                cpuGovernor = cpuGovernor,
                cpuTemp = cpuTemp,
                networkType = networkType,
                runningAppsCount = runningApps
            )
        } catch (e: Exception) {
            Log.e(TAG, "refreshStats failed", e)
        }
    }

    /**
     * AI-рекомендация режима на основе текущего состояния устройства.
     */
    fun recommendMode(stats: DeviceStats): OptimizationMode {
        return when {
            // Батарея критическая — сразу экономия
            stats.batteryLevel <= 15 && !stats.batteryCharging -> OptimizationMode.BatterySaver
            // Ночное время (можно расширить по времени суток)
            stats.batteryLevel <= 30 && !stats.batteryCharging -> OptimizationMode.BatterySaver
            // Много RAM использовано + высокая нагрузка
            stats.ramUsagePercent >= 85f -> OptimizationMode.Performance
            // CPU перегрет
            stats.cpuTemp >= 65f -> OptimizationMode.BatterySaver
            // Хорошая сеть + зарядка — игровой режим
            stats.batteryCharging && stats.networkType == "WiFi" -> OptimizationMode.Gaming
            // По умолчанию — производительность
            else -> OptimizationMode.Performance
        }
    }

    // ─── Применение оптимизации ───────────────────────────────────────────────

    suspend fun applyMode(mode: OptimizationMode): OptimizationResult =
        withContext(Dispatchers.IO) {
            _isOptimizing.value = true
            val applied = mutableListOf<String>()
            val failed = mutableListOf<String>()

            try {
                val svc = ShizukuHelper.service
                if (svc == null) {
                    return@withContext OptimizationResult(
                        success = false,
                        appliedSteps = emptyList(),
                        failedSteps = listOf("Shizuku"),
                        message = "Shizuku не подключён"
                    )
                }

                val p = mode.params

                // 1. CPU governor
                runStep("CPU Governor (${p.cpuGovernor})", applied, failed) {
                    svc.setCpuGovernor(p.cpuGovernor)
                }

                // 2. GPU governor
                runStep("GPU Governor (${p.gpuGovernor})", applied, failed) {
                    svc.setGpuGovernor(p.gpuGovernor)
                }

                // 3. Анимации
                runStep("Анимации (${p.animationScale}x)", applied, failed) {
                    svc.setAnimationScale(p.animationScale)
                }

                // 4. Яркость
                if (p.screenBrightness >= 0) {
                    runStep("Яркость (${p.screenBrightness})", applied, failed) {
                        svc.setBrightness(p.screenBrightness)
                        svc.setAdaptiveBrightnessEnabled(p.adaptiveBrightness)
                    }
                }

                // 5. WiFi
                runStep("WiFi (${if (p.wifiEnabled) "вкл" else "выкл"})", applied, failed) {
                    svc.setWifiEnabled(p.wifiEnabled)
                    svc.setWifiScanAlwaysAvailable(p.wifiScanAlways)
                }

                // 6. Мобильные данные
                runStep("Мобильные данные", applied, failed) {
                    svc.setMobileDataEnabled(p.mobileDataEnabled)
                }

                // 7. Фоновые приложения
                if (p.killBackgroundApps) {
                    runStep("Убийство фоновых приложений", applied, failed) {
                        val packages = svc.getRunningPackages()
                            .filter { it != context.packageName } // не убиваем себя
                        svc.killBackgroundApps(packages)
                    }
                }

                // 8. Doze режим
                runStep("Doze (${if (p.dozeEnabled) "вкл" else "выкл"})", applied, failed) {
                    svc.setDozeEnabled(p.dozeEnabled)
                }

                // 9. Очистка кэша
                if (p.dropCaches) {
                    runStep("Очистка кэшей", applied, failed) {
                        svc.dropCaches()
                    }
                }

                // 10. DNS
                p.dnsOverride?.let { (primary, secondary) ->
                    runStep("DNS ($primary)", applied, failed) {
                        svc.setDnsServer(primary, secondary)
                    }
                }

                delay(500) // Небольшая пауза для стабилизации
                _currentMode.value = mode

                OptimizationResult(
                    success = failed.isEmpty(),
                    appliedSteps = applied,
                    failedSteps = failed,
                    message = if (failed.isEmpty()) {
                        "✅ Режим «${mode.displayName}» применён (${applied.size} операций)"
                    } else {
                        "⚠️ Применено ${applied.size}, ошибок: ${failed.size}"
                    }
                )
            } catch (e: Exception) {
                Log.e(TAG, "applyMode failed", e)
                OptimizationResult(
                    success = false,
                    appliedSteps = applied,
                    failedSteps = failed + "Критическая ошибка",
                    message = "❌ ${e.message}"
                )
            } finally {
                _isOptimizing.value = false
            }
        }

    // ─── Вспомогательные методы ───────────────────────────────────────────────

    private fun runStep(
        name: String,
        applied: MutableList<String>,
        failed: MutableList<String>,
        block: () -> Unit
    ) {
        try {
            block()
            applied.add(name)
        } catch (e: Exception) {
            Log.e(TAG, "Step '$name' failed", e)
            failed.add(name)
        }
    }

    private fun readFile(path: String): String? = try {
        File(path).readText().trim()
    } catch (e: Exception) { null }

    private fun readCpuTemp(): Float {
        val paths = listOf(
            "/sys/class/thermal/thermal_zone0/temp",
            "/sys/devices/virtual/thermal/thermal_zone0/temp",
            "/sys/class/hwmon/hwmon0/temp1_input"
        )
        for (path in paths) {
            val raw = readFile(path)?.toLongOrNull() ?: continue
            return if (raw > 1000) raw / 1000f else raw.toFloat()
        }
        return 0f
    }

    private fun getNetworkType(): String {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val nc = cm.getNetworkCapabilities(cm.activeNetwork) ?: return "нет сети"
        return when {
            nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WiFi"
            nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Мобильная сеть"
            nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "неизвестно"
        }
    }
}
