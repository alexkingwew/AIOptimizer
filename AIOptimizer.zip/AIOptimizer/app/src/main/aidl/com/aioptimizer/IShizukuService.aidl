// IShizukuService.aidl
package com.aioptimizer;

interface IShizukuService {
    // CPU управление
    void setCpuGovernor(String governor);
    void setCpuMaxFreq(int cpuIndex, long freqKhz);
    String getCpuGovernor();

    // GPU управление
    void setGpuGovernor(String governor);

    // Процессы
    void killBackgroundApps(in List<String> packageNames);
    List<String> getRunningPackages();

    // Сеть
    void setWifiEnabled(boolean enabled);
    void setMobileDataEnabled(boolean enabled);
    void setWifiScanAlwaysAvailable(boolean enabled);

    // Дисплей
    void setBrightness(int brightness);
    void setAdaptiveBrightnessEnabled(boolean enabled);
    void setAnimationScale(float scale);
    void setWindowAnimationScale(float scale);
    void setTransitionAnimationScale(float scale);
    void setAnimatorDurationScale(float scale);

    // Доп. оптимизации
    void setDozeEnabled(boolean enabled);
    void setDnsServer(String primary, String secondary);
    void dropCaches();

    // Служебные
    void destroy();
    int getVersion();
}
