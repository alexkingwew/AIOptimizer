# Shizuku
-keep class rikka.shizuku.** { *; }
-keep class moe.shizuku.** { *; }

# AIDL generated stubs
-keep class com.aioptimizer.IShizukuService { *; }
-keep class com.aioptimizer.IShizukuService$** { *; }
-keep class com.aioptimizer.IShizukuService$Stub { *; }

# Shizuku UserService — должен быть доступен по имени класса
-keep class com.aioptimizer.service.ShizukuUserService { *; }

# Kotlin coroutines
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}

# DataStore
-keepclassmembers class * extends com.google.protobuf.GeneratedMessageLite$* {
    <fields>;
}
